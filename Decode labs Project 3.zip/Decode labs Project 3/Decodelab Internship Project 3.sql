Create Database if not exists DecodeLab;
Use DecodeLab;
Show Tables;
SELECT * From decodelab.cleaned_data;
Rename Table decodelab.cleaned_data To Orders;
select * from Orders;
Alter Table Orders RENAME COLUMN ï»¿OrderID TO OrderID;
-- View only key columns

-- Top 10 most expensive orders
SELECT OrderID, Product, TotalPrice
FROM orders
ORDER BY TotalPrice DESC
LIMIT 10;

-- Only delivered orders
SELECT * FROM orders
WHERE OrderStatus = 'Delivered';

-- Orders with TotalPrice above 1000
SELECT OrderID, Product, TotalPrice
FROM orders
WHERE TotalPrice >= 1000;

-- Laptop orders that were cancelled
SELECT * FROM orders
WHERE Product = 'Laptop' AND OrderStatus = 'Cancelled';

-- Orders referred from Instagram
SELECT * FROM orders
WHERE ReferralSource = 'Instagram';

-- Orders using a coupon
SELECT * FROM orders
WHERE CouponCode IS NOT NULL;

-- How many orders per product?
SELECT Product, COUNT(*) AS TotalOrders
FROM orders
GROUP BY Product
ORDER BY TotalOrders DESC;

-- Total revenue per product
SELECT Product, SUM(TotalPrice) AS TotalRevenue
FROM orders
GROUP BY Product
ORDER BY TotalRevenue DESC;

-- Average order value per payment method
SELECT PaymentMethod, AVG(TotalPrice) AS AvgOrderValue
FROM orders
GROUP BY PaymentMethod
ORDER BY AvgOrderValue DESC;

-- Order count by status
SELECT OrderStatus, COUNT(*) AS Count
FROM orders
GROUP BY OrderStatus;

-- Revenue by referral source
SELECT ReferralSource, SUM(TotalPrice) AS Revenue
FROM orders
GROUP BY ReferralSource
ORDER BY Revenue DESC;

-- Average revenue per product, for delivered orders only
SELECT Product, AVG(TotalPrice) AS AvgRevenue
FROM orders
WHERE OrderStatus = 'Delivered'
GROUP BY Product
ORDER BY AvgRevenue DESC;

-- Which coupon code generated the most revenue?
SELECT CouponCode, COUNT(*) AS Uses, SUM(TotalPrice) AS TotalRevenue
FROM orders
WHERE CouponCode IS NOT NULL
GROUP BY CouponCode
ORDER BY TotalRevenue DESC;

